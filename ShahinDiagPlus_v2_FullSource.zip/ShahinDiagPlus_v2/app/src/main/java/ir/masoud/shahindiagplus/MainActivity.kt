package ir.masoud.shahindiagplus

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.min

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val adapter: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var input: InputStream? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var polling = false
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private lateinit var speedGauge: GaugeView
    private lateinit var rpmGauge: GaugeView
    private lateinit var coolantValue: TextView
    private lateinit var voltageValue: TextView
    private lateinit var loadValue: TextView
    private lateinit var mafValue: TextView
    private lateinit var instantValue: TextView
    private lateinit var averageValue: TextView
    private lateinit var fuelLevelValue: TextView
    private lateinit var rangeValue: TextView
    private lateinit var tripDistanceValue: TextView
    private lateinit var tripFuelValue: TextView
    private lateinit var tripTimeValue: TextView
    private lateinit var tripAverageValue: TextView
    private lateinit var logValue: TextView
    private lateinit var dtcButton: Button
    private lateinit var clearButton: Button
    private var tankCapacity: Double? = null
    private var tripFuel = 0.0
    private var tripDistance = 0.0
    private var tripSeconds = 0L
    private var lastTick = 0L
    private var lastFuelRate: Double? = null
    private var lastSpeed: Int? = null
    private var lastRpm: Int? = null
    private var lastCoolant: Int? = null
    private var lastVoltage: Double? = null
    private var lastLoad: Int? = null
    private var lastMaf: Double? = null
    private var lastFuelPercent: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("trip", Context.MODE_PRIVATE)
        tankCapacity = if (p.contains("tank")) p.getFloat("tank", 0f).toDouble().takeIf { it > 0 } else null
        tripFuel = p.getFloat("fuel", 0f).toDouble()
        tripDistance = p.getFloat("distance", 0f).toDouble()
        tripSeconds = p.getLong("seconds", 0L)
        buildScreen(); requestBluetoothPermission(); renderTrip(null)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun label(s: String, size: Float, color: Int = 0xFFEAF2F8.toInt(), bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER; if (bold) setTypeface(typeface, 1); setPadding(dp(4), dp(5), dp(4), dp(5))
    }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(0xFF18232E.toInt()) }
    private fun gap(parent: LinearLayout, h: Int = 10) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0B1118.toInt()) }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(22)) }
        page.addView(label("شاهین دیاگ پلاس", 26f, -1, true))
        page.addView(label("SHAHIN PLUS  •  OBD-II  •  نسخه ۲.۰", 11f, 0xFF8FA5B8.toInt()))
        gap(page, 12)
        val statusCard = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        status = label("●  آماده اتصال به ELM327", 13f, 0xFFFFC857.toInt(), true)
        statusCard.addView(status, LinearLayout.LayoutParams(0, dp(42), 1f))
        connectButton = Button(this).apply { text = "اتصال"; isAllCaps = false; setTextColor(0xFF07131B.toInt()); background = bg(0xFF22C7B8.toInt(), 12); setOnClickListener { chooseDevice() } }
        statusCard.addView(connectButton, LinearLayout.LayoutParams(dp(104), dp(44))); page.addView(statusCard)
        gap(page, 14)
        val gauges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        speedGauge = GaugeView(this, "سرعت", "km/h", 240, 0xFF22C7B8.toInt())
        rpmGauge = GaugeView(this, "دور موتور", "rpm", 8000, 0xFFFFB454.toInt())
        gauges.addView(speedGauge, LinearLayout.LayoutParams(0, dp(190), 1f).apply { marginEnd = dp(6) })
        gauges.addView(rpmGauge, LinearLayout.LayoutParams(0, dp(190), 1f).apply { marginStart = dp(6) }); page.addView(gauges)
        gap(page, 12); page.addView(title("اطلاعات خودرو"))
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val r1 = metricRow("دمای آب", "-- °C", "ولتاژ ECU", "-- V"); coolantValue = r1.first; voltageValue = r1.second; metrics.addView(r1.third)
        gap(metrics, 8)
        val r2 = metricRow("بار موتور", "-- %", "جریان هوا MAF", "-- g/s"); loadValue = r2.first; mafValue = r2.second; metrics.addView(r2.third)
        gap(metrics, 8)
        val r3 = metricRow("مصرف لحظه‌ای", "-- L/100km", "سطح باک", "نامشخص"); instantValue = r3.first; fuelLevelValue = r3.second; metrics.addView(r3.third)
        gap(metrics, 8)
        val r4 = metricRow("میانگین مصرف سفر", "-- L/100km", "برد تخمینی", "نامشخص"); averageValue = r4.first; rangeValue = r4.second; metrics.addView(r4.third)
        page.addView(metrics); gap(page, 14); page.addView(title("اطلاعات سفر"))
        val trip = card()
        val t1 = metricRow("مسافت سفر", "0.00 km", "مدت سفر", "00:00"); tripDistanceValue = t1.first; tripTimeValue = t1.second; trip.addView(t1.third)
        gap(trip, 8)
        val t2 = metricRow("سوخت مصرف‌شده", "0.00 L", "میانگین سفر", "-- L/100km"); tripFuelValue = t2.first; tripAverageValue = t2.second; trip.addView(t2.third)
        gap(trip, 8); trip.addView(label("محاسبه سفر از سرعت و نرخ سوخت ECU/MAF انجام می‌شود. در نبود داده، مقدار نامشخص نمایش داده می‌شود.", 10f, 0xFF91A5B5.toInt()))
        page.addView(trip); gap(page, 12)
        val rowA = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dtcButton = action("خواندن خطاها") { readCodes() }.apply { isEnabled = false }
        clearButton = action("پاک‌کردن خطاها") { confirmClear() }.apply { isEnabled = false }
        rowA.addView(dtcButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        rowA.addView(clearButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) }); page.addView(rowA)
        gap(page, 8)
        val rowB = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowB.addView(action("تنظیم ظرفیت باک") { editTank() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        rowB.addView(action("صفرکردن سفر") { resetTrip() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) }); page.addView(rowB)
        gap(page, 12); page.addView(title("وضعیت ارتباط و پاسخ دانگل"))
        logValue = label("برای شروع، دانگل ELM327 را به خودرو وصل و از تنظیمات بلوتوث گوشی Pair کنید.", 10f, 0xFF9CB0C0.toInt()).apply { gravity = Gravity.START; background = bg(0xFF131D27.toInt(), 12); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        page.addView(logValue); page.addView(label("ساخته‌شده برای پروژه شاهین دیاگ پلاس • مسعود بادکوبه", 10f, 0xFF63798B.toInt()))
        scroll.addView(page); root.addView(scroll); setContentView(root)
    }
    private fun title(s: String) = label(s, 15f, 0xFFDAE7F1.toInt(), true).apply { gravity = Gravity.START }
    private fun metricRow(a: String, av: String, b: String, bv: String): Triple<TextView, TextView, LinearLayout> {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tile(name: String, value: String): Pair<LinearLayout, TextView> {
            val box = card().apply { gravity = Gravity.CENTER }; box.addView(label(name, 10f, 0xFF8FA5B8.toInt()))
            val v = label(value, 15f, -1, true); box.addView(v); return box to v
        }
        val (left, lv) = tile(a, av); val (right, rv) = tile(b, bv)
        row.addView(left, LinearLayout.LayoutParams(0, dp(78), 1f).apply { marginEnd = dp(5) })
        row.addView(right, LinearLayout.LayoutParams(0, dp(78), 1f).apply { marginStart = dp(5) }); return Triple(lv, rv, row)
    }
    private fun action(s: String, fn: () -> Unit) = Button(this).apply { text = s; isAllCaps = false; textSize = 12f; setTextColor(0xFFEAF2F8.toInt()); background = bg(0xFF263746.toInt(), 12); setOnClickListener { fn() } }
    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 101)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) status.text = "مجوز بلوتوث داده نشد"
    }
    private fun chooseDevice() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBluetoothPermission(); return }
        val a = adapter
        if (a == null) { toast("بلوتوث در این گوشی موجود نیست"); return }
        if (!a.isEnabled) { toast("بلوتوث گوشی را روشن کنید"); return }
        val devices = try { a.bondedDevices?.toList().orEmpty() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) { toast("ابتدا ELM327 را از تنظیمات بلوتوث Pair کنید؛ رمز رایج 1234 یا 0000 است"); return }
        AlertDialog.Builder(this).setTitle("انتخاب دانگل ELM327")
            .setItems(devices.map { "${it.name ?: "Bluetooth"} (${it.address})" }.toTypedArray()) { _, i -> connect(devices[i]) }
            .setNegativeButton("انصراف", null).show()
    }
    private fun connect(device: BluetoothDevice) {
        connectButton.isEnabled = false; status.text = "در حال اتصال…"
        thread {
            try {
                closeConnection(); val s = device.createRfcommSocketToServiceRecord(spp); s.connect()
                socket = s; input = s.inputStream; output = s.outputStream
                val init = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")
                val lines = init.map { "$it → ${send(it)}" }
                connected = true; polling = true
                runOnUiThread {
                    status.text = "● متصل به ${device.name ?: "ELM327"}"; status.setTextColor(0xFF37D6A5.toInt())
                    connectButton.text = "متصل"; dtcButton.isEnabled = true; clearButton.isEnabled = true
                    logValue.text = lines.joinToString("\n") + "\nدر حال دریافت پارامترها…"
                }
                pollLoop()
            } catch (e: Exception) {
                closeConnection(); runOnUiThread {
                    status.text = "● اتصال برقرار نشد"; status.setTextColor(0xFFFF8A80.toInt())
                    connectButton.isEnabled = true; connectButton.text = "تلاش مجدد"
                    logValue.text = "خطا: ${e.message}\nمطمئن شوید دانگل Pair شده و از نوع Bluetooth Classic است."
                }
            }
        }
    }
    @Synchronized private fun send(command: String): String {
        val out = output ?: return ""; val ins = input ?: return ""
        out.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII)); out.flush()
        val result = StringBuilder(); val start = System.currentTimeMillis(); var quiet = start
        while (System.currentTimeMillis() - start < 2200) {
            if (ins.available() > 0) {
                val b = ins.read(); if (b >= 0) { val c = b.toChar(); if (c == '>') break; result.append(c); quiet = System.currentTimeMillis() }
            } else { if (result.isNotEmpty() && System.currentTimeMillis() - quiet > 220) break; Thread.sleep(10) }
        }
        return result.toString().uppercase(Locale.US).replace(command.uppercase(Locale.US), "").replace(Regex("[\\r\\n\\t >]"), "").trim()
    }
    private fun pollLoop() {
        val pids = listOf("010C", "010D", "0105", "0142", "0104", "0110", "012F", "015E")
        while (polling && connected) {
            val replies = mutableMapOf<String, String>()
            for (pid in pids) { if (!polling) break; replies[pid] = send(pid) }
            lastRpm = data(replies["010C"], 0x41, 0x0C)?.let { ((it[0] * 256 + it[1]) / 4.0).toInt() }
            lastSpeed = data(replies["010D"], 0x41, 0x0D)?.firstOrNull()
            lastCoolant = data(replies["0105"], 0x41, 0x05)?.firstOrNull()?.minus(40)
            lastVoltage = data(replies["0142"], 0x41, 0x42)?.let { (it[0] * 256 + it[1]) / 1000.0 }
            lastLoad = data(replies["0104"], 0x41, 0x04)?.firstOrNull()?.let { it * 100 / 255 }
            lastMaf = data(replies["0110"], 0x41, 0x10)?.let { (it[0] * 256 + it[1]) / 100.0 }
            lastFuelPercent = data(replies["012F"], 0x41, 0x2F)?.firstOrNull()?.let { it * 100 / 255 }
            val directRate = data(replies["015E"], 0x41, 0x5E)?.let { (it[0] * 256 + it[1]) / 20.0 }
            lastFuelRate = directRate ?: lastMaf?.let { it * 3600.0 / (14.7 * 745.0) }
            val now = System.currentTimeMillis()
            val dt = if (lastTick == 0L) 0.0 else (now - lastTick).coerceAtMost(10000L) / 1000.0
            if (dt > 0 && dt <= 10.0) {
                tripSeconds += dt.toLong()
                lastFuelRate?.let { tripFuel += it * dt / 3600.0 }
                lastSpeed?.let { tripDistance += it * dt / 3600.0 }
            }
            lastTick = now; saveTrip()
            val speed = lastSpeed?.toDouble()
            val instant = if (speed != null && speed > 1.0 && lastFuelRate != null) lastFuelRate!! * 100.0 / speed else null
            val average = if (tripDistance > 0.05) tripFuel * 100.0 / tripDistance else null
            val remaining = if (lastFuelPercent != null && tankCapacity != null) tankCapacity!! * lastFuelPercent!! / 100.0 else null
            val range = if (remaining != null && average != null && average > 0.1) remaining * 100.0 / average else null
            runOnUiThread {
                speedGauge.setReading(lastSpeed?.toFloat() ?: 0f, lastSpeed != null)
                rpmGauge.setReading(lastRpm?.toFloat() ?: 0f, lastRpm != null)
                coolantValue.text = lastCoolant?.let { "$it °C" } ?: "پشتیبانی‌نشده"
                voltageValue.text = lastVoltage?.let { "${fmt(it, 2)} V" } ?: "پشتیبانی‌نشده"
                loadValue.text = lastLoad?.let { "$it %" } ?: "پشتیبانی‌نشده"
                mafValue.text = lastMaf?.let { "${fmt(it, 1)} g/s" } ?: "پشتیبانی‌نشده"
                instantValue.text = instant?.let { "${fmt(it, 1)} L/100" } ?: "—"
                averageValue.text = average?.let { "${fmt(it, 1)} L/100" } ?: "در حال محاسبه"
                fuelLevelValue.text = lastFuelPercent?.let { "$it %" } ?: "پشتیبانی‌نشده"
                rangeValue.text = range?.let { "${fmt(it, 0)} km" } ?: "نامشخص"
                renderTrip(average)
                logValue.text = (if (directRate != null) "نرخ سوخت مستقیم ECU" else if (lastMaf != null) "مصرف سوخت تخمینی از MAF" else "نرخ سوخت در دسترس نیست") + "\n" +
                    pids.joinToString("   ") { key -> if (data(replies[key], 0x41, key.substring(2).toInt(16)) != null) "$key ✓" else "$key —" }
            }
            Thread.sleep(180)
        }
    }
    private fun data(raw: String?, mode: Int, pid: Int): List<Int>? {
        if (raw.isNullOrBlank()) return null
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val marker = "%02X%02X".format(mode, pid); val start = hex.indexOf(marker)
        if (start < 0) return null
        val body = hex.substring(start + 4); if (body.length < 2) return null
        return try { body.chunked(2).filter { it.length == 2 }.map { it.toInt(16) } } catch (_: Exception) { null }
    }
    private fun renderTrip(avg: Double?) {
        tripDistanceValue.text = "${fmt(tripDistance, 2)} km"; tripFuelValue.text = "${fmt(tripFuel, 2)} L"
        tripTimeValue.text = "%02d:%02d".format(tripSeconds / 3600, (tripSeconds % 3600) / 60)
        tripAverageValue.text = avg?.let { "${fmt(it, 1)} L/100" } ?: if (tripDistance > 0.05) "${fmt(tripFuel * 100 / tripDistance, 1)} L/100" else "—"
    }
    private fun saveTrip() {
        getSharedPreferences("trip", Context.MODE_PRIVATE).edit().putFloat("tank", (tankCapacity ?: 0.0).toFloat())
            .putFloat("fuel", tripFuel.toFloat()).putFloat("distance", tripDistance.toFloat()).putLong("seconds", tripSeconds).apply()
    }
    private fun editTank() {
        val field = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; hint = "ظرفیت باک به لیتر"; setText(tankCapacity?.toString() ?: "") }
        AlertDialog.Builder(this).setTitle("ظرفیت باک").setMessage("ظرفیت را از دفترچه یا مشخصات معتبر خودرو وارد کنید. سطح باک فقط در صورت پشتیبانی ECU قابل محاسبه است.")
            .setView(field).setNegativeButton("لغو", null).setPositiveButton("ذخیره") { _, _ ->
                val v = field.text.toString().replace(',', '.').toDoubleOrNull()
                if (v == null || v !in 5.0..150.0) toast("عدد معتبر وارد کنید") else { tankCapacity = v; saveTrip(); toast("ظرفیت باک ذخیره شد") }
            }.show()
    }
    private fun resetTrip() {
        AlertDialog.Builder(this).setTitle("صفرکردن سفر").setMessage("مسافت، زمان و سوخت مصرف‌شده سفر صفر می‌شوند.")
            .setNegativeButton("لغو", null).setPositiveButton("صفر کن") { _, _ ->
                tripFuel = 0.0; tripDistance = 0.0; tripSeconds = 0L; lastTick = 0L; saveTrip(); renderTrip(null); toast("اطلاعات سفر صفر شد")
            }.show()
    }
    private fun readCodes() {
        if (!connected) return
        thread { val raw = send("03"); val codes = decodeCodes(raw, 0x43)
            runOnUiThread { AlertDialog.Builder(this).setTitle("خطاهای عمومی موتور")
                .setMessage(if (codes.isEmpty()) "کد خطای عمومی دریافت نشد یا ECU پاسخ نداد.\nپاسخ: $raw\nاین بخش فقط خطاهای عمومی موتور را می‌خواند." else codes.joinToString("\n") { "$it — ${description(it)}" })
                .setPositiveButton("بستن", null).show() }
        }
    }
    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle("پاک‌کردن خطاها؟").setMessage("ابتدا کدها را یادداشت و علت خرابی را رفع کنید. پاک‌کردن خطا ممکن است داده Freeze Frame و وضعیت آمادگی آلایندگی را حذف کند.")
            .setNegativeButton("انصراف", null).setPositiveButton("پاک کن") { _, _ -> thread { val r = send("04"); runOnUiThread { toast("پاسخ ECU: $r") } } }.show()
    }
    private fun decodeCodes(raw: String, mode: Int): List<String> {
        val hex = raw.replace(Regex("[^0-9A-Fa-f]"), "").uppercase(Locale.US); val start = hex.indexOf("%02X".format(mode)); if (start < 0) return emptyList()
        val bytes = hex.substring(start + 2).chunked(2).filter { it.length == 2 }.mapNotNull { it.toIntOrNull(16) }
        val out = mutableListOf<String>(); var i = 0
        while (i + 1 < bytes.size) { val a = bytes[i]; val b = bytes[i + 1]; i += 2; if (a == 0 && b == 0) continue
            val prefix = charArrayOf('P', 'C', 'B', 'U')[(a shr 6) and 3]
            out.add("$prefix${(a shr 4) and 3}${(a and 15).toString(16).uppercase(Locale.US)}${b.toString(16).uppercase(Locale.US).padStart(2, '0')}") }
        return out
    }
    private fun description(c: String) = when (c) {
        "P0100" -> "اختلال مدار سنسور جریان هوای ورودی"; "P0101" -> "محدوده/عملکرد سنسور جریان هوا"
        "P0115" -> "اختلال مدار سنسور دمای آب"; "P0120" -> "اختلال مدار سنسور دریچه گاز"
        "P0130" -> "اختلال مدار سنسور اکسیژن"; "P0171" -> "مخلوط سوخت و هوای رقیق"
        "P0172" -> "مخلوط سوخت و هوای غنی"; "P0300" -> "احتراق ناقص تصادفی/چند سیلندر"
        "P0301" -> "احتراق ناقص سیلندر ۱"; "P0302" -> "احتراق ناقص سیلندر ۲"; "P0303" -> "احتراق ناقص سیلندر ۳"
        "P0304" -> "احتراق ناقص سیلندر ۴"; "P0420" -> "بازده کاتالیزور پایین"; "P0500" -> "اختلال سیگنال سرعت خودرو"
        "P0560" -> "اختلال ولتاژ سیستم"; else -> "شرح در پایگاه داخلی نیست؛ با دستگاه تخصصی بررسی شود."
    }
    private fun closeConnection() { polling = false; connected = false; try { socket?.close() } catch (_: Exception) {}; socket = null; input = null; output = null }
    override fun onDestroy() { closeConnection(); saveTrip(); super.onDestroy() }
    private fun fmt(v: Double, digits: Int) = String.format(Locale.US, "%.$digits" + "f", v)
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
}

private class GaugeView(context: Context, private val title: String, private val unit: String, private val maxValue: Int, private val accent: Int) : View(context) {
    private val arc = Paint(3).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val text = Paint(3).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private var value = 0f; private var available = false; private val rect = RectF()
    fun setReading(v: Float, valid: Boolean) { value = v.coerceIn(0f, maxValue.toFloat()); available = valid; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h * .53f
        val radius = min(w * .39f, h * .39f); rect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        arc.strokeWidth = radius * .12f; arc.color = 0xFF30404F.toInt(); canvas.drawArc(rect, 135f, 270f, false, arc)
        if (available) { arc.color = accent; canvas.drawArc(rect, 135f, 270f * (value / maxValue), false, arc) }
        text.color = 0xFF9FB2C2.toInt(); text.textSize = radius * .19f; canvas.drawText(title, cx, cy - radius * .39f, text)
        text.color = -1; text.textSize = radius * .48f; canvas.drawText(if (available) value.toInt().toString() else "--", cx, cy + radius * .13f, text)
        text.color = 0xFF9FB2C2.toInt(); text.textSize = radius * .18f; canvas.drawText(unit, cx, cy + radius * .43f, text)
        text.color = accent; text.textSize = radius * .15f; canvas.drawText("0", cx - radius * .72f, cy + radius * .66f, text); canvas.drawText(maxValue.toString(), cx + radius * .72f, cy + radius * .66f, text)
    }
}
