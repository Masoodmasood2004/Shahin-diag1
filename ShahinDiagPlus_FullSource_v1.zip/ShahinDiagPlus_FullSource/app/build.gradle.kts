plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.masoud.shahindiagplus"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.masoud.shahindiagplus"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
