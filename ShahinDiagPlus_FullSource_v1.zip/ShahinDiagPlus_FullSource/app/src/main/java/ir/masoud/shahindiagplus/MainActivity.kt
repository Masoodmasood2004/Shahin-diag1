package ir.masoud.shahindiagplus

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val bt: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var input: InputStream? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var polling = false

    private lateinit var status: TextView
    private lateinit var dashboard: TextView
    private lateinit var messages: TextView
    private lateinit var connectBtn: Button
    private lateinit var dtcBtn: Button
    private lateinit var clearBtn: Button
    private lateinit var settingsBtn: Button
    private lateinit var tripBtn: Button

    private var tankCapacityLitres: Double? = null
    private var tripFuelLitres = 0.0
    private var tripDistanceKm = 0.0
    private var lastTick = 0L
    private var lastFuelRate: Double? = null
    private var lastSpeed: Int? = null
    private var lastFuelLevelPercent: Int? = null
    private var lastRpm: Int? = null
    private var lastCoolant: Int? = null
    private var lastVoltage: Double? = null
    private var lastLoad: Int? = null
    private var lastMaf: Double? = null
    private var supportedPids = mutableSetOf<Int>()
    private var lastRaw = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        requestBluetoothPermission()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun text(s: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply {
                text = s; textSize = size; setTextColor(color)
                gravity = Gravity.CENTER; setPadding(4, 7, 4, 7)
            }
        page.addView(text("شاهین دیاگ پلاس", 25f))
        page.addView(text("نسخه ۱.۰ • شاهین پلاس / ELM327", 13f, 0xFFB0BEC5.toInt()))
        status = text("وضعیت: آماده اتصال", 15f, 0xFFFFC857.toInt())
        page.addView(status)
        connectBtn = Button(this).apply {
            text = "انتخاب دانگل و اتصال"
            setOnClickListener { choosePairedDevice() }
        }
        page.addView(connectBtn)
        dashboard = text(
            "سرعت: -- km/h       دور موتور: -- rpm\n" +
            "دمای آب: -- °C       ولتاژ ECU: -- V\n" +
            "بار موتور: -- %       MAF: -- g/s\n" +
            "مصرف لحظه‌ای: -- L/100km\n" +
            "میانگین سفر: -- L/100km\n" +
            "سطح باک: -- %       بنزین تخمینی: -- L\n" +
            "مسافت قابل پیمایش: -- km", 16f
        )
        page.addView(dashboard)
        val buttons1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dtcBtn = Button(this).apply {
            text = "خواندن خطاها"; isEnabled = false; setOnClickListener { readTroubleCodes() }
        }
        clearBtn = Button(this).apply {
            text = "پاک‌کردن خطاها"; isEnabled = false; setOnClickListener { confirmClearCodes() }
        }
        buttons1.addView(dtcBtn, LinearLayout.LayoutParams(0, -2, 1f))
        buttons1.addView(clearBtn, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(buttons1)
        val buttons2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        settingsBtn = Button(this).apply {
            text = "تنظیم ظرفیت باک"; setOnClickListener { editTankCapacity() }
        }
        tripBtn = Button(this).apply {
            text = "صفرکردن سفر"; setOnClickListener { confirmResetTrip() }
        }
        buttons2.addView(settingsBtn, LinearLayout.LayoutParams(0, -2, 1f))
        buttons2.addView(tripBtn, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(buttons2)
        messages = text("راهنما: دانگل را به سوکت OBD وصل کنید، سوئیچ را روی ON بگذارید و از تنظیمات بلوتوث گوشی Pair کنید.", 12f, 0xFFB0BEC5.toInt())
        messages.gravity = Gravity.START
        page.addView(messages)
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 101)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 101 && results.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            status.text = "مجوز بلوتوث داده نشد"
        }
    }

    private fun choosePairedDevice() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermission(); return
        }
        val adapter = bt
        if (adapter == null) { toast("بلوتوث در این گوشی موجود نیست"); return }
        if (!adapter.isEnabled) { toast("ابتدا بلوتوث گوشی را روشن کنید"); return }
        val devices = try { adapter.bondedDevices?.toList().orEmpty() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) {
            toast("ابتدا از تنظیمات بلوتوث گوشی، دانگل را Pair کنید. رمز رایج 1234 یا 0000 است.")
            return
        }
        val labels = devices.map { "${it.name ?: "دستگاه ناشناس"}  (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("انتخاب دانگل ELM327")
            .setItems(labels) { _, index -> connectTo(devices[index]) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun connectTo(device: BluetoothDevice) {
        connectBtn.isEnabled = false
        status.text = "وضعیت: در حال اتصال..."
        thread {
            try {
                closeConnection()
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s; input = s.inputStream; output = s.outputStream
                val init = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0", "0100")
                val initLog = init.joinToString("\n") { "$it  →  ${sendCommand(it)}" }
                connected = true
                polling = true
                runOnUiThread {
                    status.text = "متصل: ${device.name ?: "ELM327"}"
                    connectBtn.text = "اتصال برقرار است"
                    dtcBtn.isEnabled = true; clearBtn.isEnabled = true
                    messages.text = "راه‌اندازی دانگل انجام شد.\n$initLog"
                }
                pollData()
            } catch (e: Exception) {
                closeConnection()
                runOnUiThread {
                    status.text = "اتصال ناموفق"
                    connectBtn.isEnabled = true
                    connectBtn.text = "تلاش مجدد برای اتصال"
                    messages.text = "خطا: ${e.message}\nمطمئن شوید دانگل Pair شده و از نوع Bluetooth Classic است."
                }
            }
        }
    }

    @Synchronized private fun sendCommand(command: String): String {
        val out = output ?: return ""
        val ins = input ?: return ""
        out.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII))
        out.flush()
        val response = StringBuilder()
        val start = System.currentTimeMillis()
        var quietSince = start
        while (System.currentTimeMillis() - start < 2500) {
            if (ins.available() > 0) {
                val b = ins.read()
                if (b >= 0) {
                    val c = b.toChar()
                    if (c == '>') break
                    response.append(c)
                    quietSince = System.currentTimeMillis()
                }
            } else {
                if (response.isNotEmpty() && System.currentTimeMillis() - quietSince > 250) break
                Thread.sleep(12)
            }
        }
        val cleaned = response.toString().uppercase(Locale.US)
            .replace(command.uppercase(Locale.US), "")
            .replace(Regex("[\\r\\n\\t ]"), "")
        lastRaw = cleaned
        return cleaned
    }

    private fun pollData() {
        val commands = listOf("010C", "010D", "0105", "0142", "0104", "0110", "012F", "015E")
        while (polling && connected) {
            val answers = mutableMapOf<String, String>()
            for (cmd in commands) {
                if (!polling) break
                answers[cmd] = sendCommand(cmd)
            }
            lastRpm = bytesFor(answers["010C"], 0x41, 0x0C)?.let { ((it[0] * 256 + it[1]) / 4.0).toInt() }
            lastSpeed = bytesFor(answers["010D"], 0x41, 0x0D)?.get(0)
            lastCoolant = bytesFor(answers["0105"], 0x41, 0x05)?.get(0)?.minus(40)
            lastVoltage = bytesFor(answers["0142"], 0x41, 0x42)?.let { (it[0] * 256 + it[1]) / 1000.0 }
            lastLoad = bytesFor(answers["0104"], 0x41, 0x04)?.get(0)?.let { it * 100 / 255 }
            lastMaf = bytesFor(answers["0110"], 0x41, 0x10)?.let { (it[0] * 256 + it[1]) / 100.0 }
            lastFuelLevelPercent = bytesFor(answers["012F"], 0x41, 0x2F)?.get(0)?.let { it * 100 / 255 }
            val directFuelRate = bytesFor(answers["015E"], 0x41, 0x5E)?.let { (it[0] * 256 + it[1]) / 20.0 }
            // Fallback estimate from MAF using gasoline AFR 14.7 and density 745 g/L.
            lastFuelRate = directFuelRate ?: lastMaf?.let { it * 3600.0 / (14.7 * 745.0) }

            val now = System.currentTimeMillis()
            val dtHours = if (lastTick == 0L) 0.0 else (now - lastTick) / 3_600_000.0
            val rate = lastFuelRate
            val speed = lastSpeed
            if (dtHours in 0.0..0.03) {
                if (rate != null) tripFuelLitres += rate * dtHours
                if (speed != null) tripDistanceKm += speed * dtHours
            }
            lastTick = now
            val instant = if (rate != null && speed != null && speed > 0) rate * 100.0 / speed else null
            val average = if (tripDistanceKm > 0.1) tripFuelLitres * 100.0 / tripDistanceKm else null
            val remainingLitres = if (lastFuelLevelPercent != null && tankCapacityLitres != null)
                tankCapacityLitres!! * lastFuelLevelPercent!! / 100.0 else null
            val range = if (remainingLitres != null && average != null && average > 0.1)
                remainingLitres * 100.0 / average else null

            val display = buildString {
                append("سرعت: ${lastSpeed?.toString() ?: "--"} km/h       دور موتور: ${lastRpm?.toString() ?: "--"} rpm\n")
                append("دمای آب: ${lastCoolant?.toString() ?: "--"} °C       ولتاژ ECU: ${lastVoltage?.let { fmt(it, 2) } ?: "--"} V\n")
                append("بار موتور: ${lastLoad?.let { "$it%" } ?: "--"}       MAF: ${lastMaf?.let { fmt(it, 1) } ?: "--"} g/s\n")
                append("مصرف لحظه‌ای: ${instant?.let { fmt(it, 1) } ?: "--"} L/100km\n")
                append("میانگین سفر: ${average?.let { fmt(it, 1) } ?: "--"} L/100km\n")
                append("سطح باک: ${lastFuelLevelPercent?.let { "$it%" } ?: "پشتیبانی نمی‌شود"}\n")
                append("بنزین تخمینی: ${remainingLitres?.let { fmt(it, 1) + " L" } ?: "ظرفیت باک را تنظیم کنید"}\n")
                append("برد تخمینی: ${range?.let { fmt(it, 0) + " km" } ?: "--"}\n")
                append("سوخت مصرف‌شده سفر: ${fmt(tripFuelLitres, 2)} L   مسافت سفر: ${fmt(tripDistanceKm, 2)} km")
            }
            runOnUiThread { dashboard.text = display }
            Thread.sleep(350)
        }
    }

    private fun bytesFor(raw: String?, mode: Int, pid: Int): List<Int>? {
        if (raw.isNullOrBlank()) return null
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val header = "%02X%02X".format(mode, pid)
        val start = hex.indexOf(header)
        if (start < 0) return null
        val data = hex.substring(start + 4)
        if (data.length < 2 || data.startsWith("NODATA") || data.startsWith("UNABLE")) return null
        return try {
            data.chunked(2).takeWhile { it.length == 2 }.map { it.toInt(16) }
        } catch (_: Exception) { null }
    }

    private fun readTroubleCodes() {
        if (!connected) return
        thread {
            val response = sendCommand("03")
            val codes = decodeDtc(response, 0x43)
            runOnUiThread {
                val message = if (codes.isEmpty())
                    "کد خطای عمومی دریافت نشد یا ECU پاسخ نداد.\nپاسخ خام: $response\n\nاین بخش فقط خطاهای عمومی موتور را می‌خواند."
                else codes.joinToString("\n") { "$it — ${dtcDescription(it)}" }
                AlertDialog.Builder(this).setTitle("خطاهای عمومی موتور").setMessage(message)
                    .setPositiveButton("بستن", null).show()
            }
        }
    }

    private fun confirmClearCodes() {
        AlertDialog.Builder(this).setTitle("پاک کردن کدهای خطا؟")
            .setMessage("ابتدا کدها را یادداشت و علت خرابی را رفع کنید. پاک‌کردن خطا ممکن است داده‌های Freeze Frame و وضعیت آمادگی آلایندگی را حذف کند.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("پاک کن") { _, _ ->
                thread {
                    val response = sendCommand("04")
                    runOnUiThread { toast("پاسخ ECU: $response") }
                }
            }.show()
    }

    private fun decodeDtc(raw: String, responseMode: Int): List<String> {
        val hex = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val start = hex.indexOf("%02X".format(responseMode))
        if (start < 0) return emptyList()
        val bytes = hex.substring(start + 2).chunked(2)
            .filter { it.length == 2 }.mapNotNull { it.toIntOrNull(16) }
        val result = mutableListOf<String>()
        var i = 0
        while (i + 1 < bytes.size) {
            val a = bytes[i]; val b = bytes[i + 1]
            i += 2
            if (a == 0 && b == 0) continue
            val prefix = charArrayOf('P', 'C', 'B', 'U')[(a shr 6) and 3]
            val digit1 = (a shr 4) and 3
            result.add("$prefix$digit1${(a and 15).toString(16).uppercase(Locale.US)}${b.toString(16).uppercase(Locale.US).padStart(2, '0')}")
        }
        return result
    }

    private fun dtcDescription(code: String): String = when (code) {
        "P0100" -> "اختلال مدار سنسور جریان هوای ورودی"
        "P0101" -> "محدوده/عملکرد سنسور جریان هوا"
        "P0115" -> "اختلال مدار سنسور دمای مایع خنک‌کننده"
        "P0116" -> "محدوده/عملکرد سنسور دمای آب"
        "P0120" -> "اختلال مدار سنسور دریچه گاز"
        "P0130" -> "اختلال مدار سنسور اکسیژن"
        "P0171" -> "مخلوط سوخت و هوای رقیق"
        "P0172" -> "مخلوط سوخت و هوای غنی"
        "P0201" -> "اختلال مدار انژکتور سیلندر ۱"
        "P0300" -> "احتراق ناقص تصادفی/چند سیلندر"
        "P0301" -> "احتراق ناقص سیلندر ۱"
        "P0302" -> "احتراق ناقص سیلندر ۲"
        "P0303" -> "احتراق ناقص سیلندر ۳"
        "P0304" -> "احتراق ناقص سیلندر ۴"
        "P0420" -> "بازده کاتالیزور پایین‌تر از حد مجاز"
        "P0500" -> "اختلال سیگنال سرعت خودرو"
        "P0560" -> "اختلال ولتاژ سیستم"
        "P0606" -> "اختلال پردازنده ECU"
        else -> "شرح عمومی در پایگاه داخلی موجود نیست؛ کد را با دستگاه تخصصی بررسی کنید."
    }

    private fun editTankCapacity() {
        val field = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "ظرفیت باک بر حسب لیتر"
            setText(tankCapacityLitres?.toString() ?: "")
        }
        AlertDialog.Builder(this).setTitle("تنظیم ظرفیت باک")
            .setMessage("این مقدار را از دفترچه خودرو یا مشخصات معتبر شاهین پلاس وارد کنید؛ برنامه آن را حدس نمی‌زند.")
            .setView(field)
            .setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val value = field.text.toString().toDoubleOrNull()
                if (value == null || value <= 0 || value > 150) toast("ظرفیت معتبر وارد کنید")
                else { tankCapacityLitres = value; toast("ظرفیت باک تنظیم شد") }
            }.show()
    }

    private fun confirmResetTrip() {
        AlertDialog.Builder(this).setTitle("صفرکردن اطلاعات سفر؟")
            .setMessage("مسافت و سوخت مصرف‌شده سفر از ابتدا محاسبه می‌شود.")
            .setNegativeButton("لغو", null)
            .setPositiveButton("صفر کن") { _, _ ->
                tripFuelLitres = 0.0; tripDistanceKm = 0.0; lastTick = 0L
                toast("اطلاعات سفر صفر شد")
            }.show()
    }

    private fun closeConnection() {
        polling = false; connected = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null; input = null; output = null
    }

    override fun onDestroy() { closeConnection(); super.onDestroy() }
    private fun fmt(v: Double, digits: Int) = String.format(Locale.US, "%.${digits}f", v)
    private fun toast(message: String) = runOnUiThread {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
